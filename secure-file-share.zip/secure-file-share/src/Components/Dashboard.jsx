import React from 'react'
import Signup from './Login/Signup'
import useToken from './App/useToken'


const Dashboard = () => {

  const {token, settoken }= useToken()
  if(!token) {
    return<Signup settoken={settoken} />
  }
  return (
    <div>
      <h1 className='text-white font-bold text-2xl'>DashBoard</h1>
    </div>
  )
}

export default Dashboard