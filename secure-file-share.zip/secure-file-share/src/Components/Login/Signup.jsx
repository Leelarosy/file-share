import React, {useState} from 'react'
import PropTypes from 'prop-types';
 

async function signupUser(credentials) {
    return fetch('http://localhost:3000/Login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
    })
        .then(data => data.json())
}

const Signup = ({settoken}) => {
    
    const [username, setUsername] = useState()
    const [password, setPassword] = useState()
    const [mail, setMail] = useState()

    const handleSubmit = async e => {
        window.location.href = '/uploadpage';
        e.preventDefault()
        const token = await signupUser({
            username,
            password, mail
        })
        settoken(token)
        
    }
  return (
    <>
    <div className='bg-black/50 fixed top-0 left-0 w-full h-screen'></div>
    <div className='fixed w-full px-4 py-24 z-50'>
    <div className='max-w-[450px] h-[600px] mx-auto bg-black/80 text-white'>
    <div className='max-w-[320px] mx-auto py-16'>
        <h1 className='text-center p-2 font-bold uppercase text-3xl'>Sign Up Here</h1>
        <form onSubmit={handleSubmit} className='w-full flex flex-col py-4'>
                <p className='font-bold'>UserName</p>
                <input type="text" onChange={e => setUsername(e.target.value)} required className='p-3 my-2 rounded text-black' placeholder='JohnDoe'/>
                <p className='font-bold'>Emailid</p>
                <input type="email" onChange={e => setMail(e.target.value)} required className='p-3 my-2 rounded text-black' placeholder='xxx@xxx.com'/>
                <p className='font-bold'>PassWord</p>
                <input type="password" onChange={e => setPassword(e.target.value)} required className='p-3 my-2 rounded text-black' placeholder='Please enter a strong password'/>
            <button type="submit" className='bg-red-700 py-3 my-6 rounded font-bold px-4'>Submit</button>
            
        </form>
    </div>
    </div>
    </div>
    </>
  )
}

Signup.propTypes={
    settoken: PropTypes.func.isRequired
}

export default Signup