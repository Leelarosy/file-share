import React, {useState} from 'react';
import axios from 'axios';
export const UploadPage = () =>{
    const [file, setFile] = useState();
    const [uploadedFile, setUploadedFile] = useState();
    const [error, setError] = useState();
  
    function handleChange(event) {
      setFile(event.target.files[0]);
    }
    
    function handleSubmit(event) {
      event.preventDefault();
      const url = 'http://localhost:3000/uploadpage';
      const formData = new FormData();
      formData.append('file', file);
      formData.append('fileName', file.name);
      const config = {
        headers: {
          'content-type': 'multipart/form-data',
        },
      };
      axios.post(url, formData, config)
        .then((response) => {
          console.log(response.data);
          setUploadedFile(response.data.file);
        })
        .catch((error) => {
          console.error("Error uploading file: ", error);
          setError(error);
        });
    }
 return(
    <>
     <div className='bg-black/50 fixed top-0 left-0 w-full h-screen'>
    <div className='fixed w-full px-4 py-24 z-50'>
    <div className='max-w-[450px] h-[600px] mx-auto bg-black/80 text-white'>
      
    <div className='max-w-[320px] mx-auto py-16'> 
    <h1 className='text-center p-2 font-bold uppercase text-3xl'>File Upload</h1>
         <form onSubmit={handleSubmit} className='flex' >
          <div className='flex-1 p-3'>
           <input type="file" onChange={handleChange} class="text-white"/>
           <button type="submit" className='bg-red-700 py-3 my-6 rounded font-bold px-4'>Upload</button>
            
           </div>
        </form>
        {uploadedFile && <img src={uploadedFile} alt="Uploaded content"/>}
        {error && <p class="text-gray">Error uploading file: {error.message}</p>}

        </div></div></div></div>

        </>

 )
}